#!/usr/bin/env python
# coding: utf-8

# In[1]:


#20


# In[4]:


pricepermonth = 48584 # 매달 내야하는 금액 제시
month = 36 # 무이자 몇 개월인지 
totalprice = month * pricepermonth # 총금액은 개월 수 * 한달에 내야하는 금액
print(totalprice) # print 함수로 출력


# In[ ]:




