#!/usr/bin/env python
# coding: utf-8

# In[1]:


#100


# In[9]:


date = ['09/05', '09/06', '09/07', '09/08', '09/09']
close_price = [10500, 10300, 10100, 10800, 11000]
close_table = dict(zip(date, close_price)) # zip 함수는 여려개의 리스트를 하나의 새로운 리스트로 만들어주는 역할을 한다. # 이거도 지금 배웠다
print(close_table)


# In[ ]:





# In[ ]:




