#!/usr/bin/env python
# coding: utf-8

# In[1]:


#40


# In[2]:


data = "    삼성전자    "
print(data)


# In[3]:


data_1 = data.strip() # strip 함수는 \n이나 공백을 지워준다. # 솔직히 처음 봤다..
print(data_1)


# In[ ]:




