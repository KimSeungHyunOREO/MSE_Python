#!/usr/bin/env python
# coding: utf-8

# In[1]:


#80


# In[3]:


a = tuple(range(2, 100, 2)) 
# 튜플로 만들기 위해서 tuple함수를 사용했다 
# 2부터 99까지 짝수만 출력하기위해 range 함수를 사용했다.
# range(시작 숫자, 마지막숫자+1, 간격)으로 사용하면 된다.
print(a)


# In[ ]:




