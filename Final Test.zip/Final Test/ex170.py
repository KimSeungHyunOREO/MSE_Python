#!/usr/bin/env python
# coding: utf-8

# In[1]:


#170


# In[12]:


num = 1 # 초기값 설정
for i in range(1, 11, 1): # range 함수를 통해 길이 지정 (시작, 끝+1, 간격)
    num *= i # = num = num * i
print(num)


# In[6]:


list(range(0,11,1))


# In[ ]:





# In[ ]:




