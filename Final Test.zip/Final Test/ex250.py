#!/usr/bin/env python
# coding: utf-8

# In[1]:


#250


# In[4]:


import numpy as np # numpy 함수 호출 하고 np로 지정
for i in np.arange(0, 5.1, 0.1): # numpy에서 arange는 일반 range와 같은 기능 (처음, 끝, 간격)
    print(i) 


# In[ ]:





# In[ ]:




