#!/usr/bin/env python
# coding: utf-8

# In[ ]:


#30


# In[3]:


string = 'abcd' # 문자열
string.replace('b', 'B') # replace는 대체하는 함수
print(string) # 문자열은 바뀌지 않는다.


# In[ ]:




