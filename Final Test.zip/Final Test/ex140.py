#!/usr/bin/env python
# coding: utf-8

# In[1]:


#140


# In[2]:


print("-------")
print("-------")
print("-------")
print("-------")
# 아래 식과 결과가 같다.


# In[3]:


# for문을 이용하여 4번 출력
a = [1, 2, 3, 4] # a 원소 개수만큼 출력시키기 위해서 4개의 원소를 가진 리스트를 만들었다.
for i in a:
    print("-------")


# In[ ]:




