#!/usr/bin/env python
# coding: utf-8

# In[1]:


#70


# In[2]:


data = [2, 4, 3, 1, 5, 10, 9]


# In[4]:


data.sort(reverse=True) # sort 함수를 이용하면 정렬 할 수 있는데 True는 오름차순이고 False는 내림차순이다.
print(data)


# In[ ]:




