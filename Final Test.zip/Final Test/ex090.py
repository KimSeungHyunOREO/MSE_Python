#!/usr/bin/env python
# coding: utf-8

# In[ ]:


#90


# In[1]:


icecream = {'폴라포': 1200, '빵빠레': 1800, '월드콘': 1500, '메로나': 1000}
icecream['누가바']


# In[ ]:


# icecream dict 에 '누가바'라는 key값이 없는데 인덱싱 하려고 해서 오류가 발생했다.  

