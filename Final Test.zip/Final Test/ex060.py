#!/usr/bin/env python
# coding: utf-8

# In[1]:


#60


# In[2]:


nums = [1, 2, 3, 4, 5]


# In[3]:


import numpy as np # numpy를 이용해서 평균을 구했다.
np.mean(nums) # numpy에서 mean 함수를 사용하면 평균이 나온다.


# In[ ]:




