#!/usr/bin/env python
# coding: utf-8

# In[1]:


#190


# In[2]:


apart = [ [101, 102], [201, 202], [301, 302] ]


# In[3]:


for floor in apart: # 층 시작
    for room_number in floor: # 호 시작
        print(room_number, "호") # 호 끝
    #층 끝
print("-----") # 아파트


# In[ ]:




