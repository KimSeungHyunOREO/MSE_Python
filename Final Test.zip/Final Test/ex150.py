#!/usr/bin/env python
# coding: utf-8

# In[1]:


#150


# In[2]:


리스트 = ["가", "나", "다", "라"] # 거꾸로 출력하기 위해서는 slice를 -1로 하면 될 것이다 


# In[3]:


for i in 리스트[::-1]:# slice[초기위치:최종위치:간격]
    print(i)


# In[ ]:




