#!/usr/bin/env python
# coding: utf-8

# In[ ]:


#220


# In[1]:


def print_max(a, b, c):
    if a > b and a > c: # a가 가장 큼을 비교연산자로 표현
        print(a)
    elif b > a and b > c: # 아니고 만약 b가 가장 크다면 
        print(b)
    else: # 전부 아니라면 
        print(c)
print_max(5, 2, 3)


# In[ ]:




