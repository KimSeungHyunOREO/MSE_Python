#!/usr/bin/env python
# coding: utf-8

# In[1]:


#230


# In[2]:


def my_print (a, b) :
    print("왼쪽:", a) 
    print("오른쪽:", b)

my_print(b=100, a=200) 
# 왼쪽: 200, 오른쪽: 100 으로 나올 것 같다
# a값은 왼쪽이고 b값은 오른쪽에 나오니까


# In[ ]:




