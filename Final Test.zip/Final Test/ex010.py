#!/usr/bin/env python
# coding: utf-8

# In[1]:


#10


# In[ ]:


print(5/3) # print() 함수를 이용하여 원하는 값 출력

